package com.stock.pilot.repository;

import com.stock.pilot.model.StockMovement;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface StockMovementRepository
        extends JpaRepository<StockMovement, UUID> {

    List<StockMovement> findByProductIdOrderByOccurredAtDesc(
            UUID productId
    );
}
