package com.stock.pilot.service;

import com.stock.pilot.dto.product.ProductCreateRequest;
import com.stock.pilot.dto.product.ProductResponse;
import com.stock.pilot.exception.DuplicateSkuException;
import com.stock.pilot.exception.ResourceNotFoundException;
import com.stock.pilot.mapper.ProductMapper;
import com.stock.pilot.model.Product;
import com.stock.pilot.model.Supplier;
import com.stock.pilot.repository.ProductRepository;
import com.stock.pilot.repository.SupplierRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ProductService {

    private final ProductRepository productRepository;
    private final SupplierRepository supplierRepository;
    private final ProductMapper productMapper;

    public ProductService(
            ProductRepository productRepository,
            SupplierRepository supplierRepository,
            ProductMapper productMapper
    ) {
        this.productRepository = productRepository;
        this.supplierRepository = supplierRepository;
        this.productMapper = productMapper;
    }

    @Transactional
    public ProductResponse createProduct(
            ProductCreateRequest request
    ) {

        if (productRepository.existsBySku(request.sku())) {
            throw new DuplicateSkuException(
                    "Product with SKU '" + request.sku() + "' already exists."
            );
        }

        Supplier supplier = null;

        if (request.supplierId() != null) {
            supplier = supplierRepository
                    .findById(request.supplierId())
                    .orElseThrow(() ->
                            new ResourceNotFoundException(
                                    "Supplier not found: "
                                            + request.supplierId()
                            )
                    );
        }

        Product product = new Product(
                request.sku(),
                request.name(),
                request.description(),
                supplier,
                request.unit(),
                request.reorderLevel()
        );

        Product savedProduct = productRepository.save(product);

        return productMapper.toResponse(savedProduct);
    }
}
